import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Employee } from './employee.model';
@Injectable({
  providedIn: 'root'
})
export class DBService {

  constructor(private http: HttpClient) { }
  url:string="http://nitinrestapi.azurewebsites.net/api/employees";
  public getRecords() {
    return this.http.get(this.url);
  }
  public saveEmployee(emp:Employee){
    return this.http.post(this.url,emp);
  }
}

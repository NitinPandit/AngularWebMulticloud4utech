import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee.model';
import { DBService } from '../db.service';

@Component({
  selector: 'app-add-new',
  templateUrl: './add-new.component.html',
  styleUrls: ['./add-new.component.css']
})
export class AddNewComponent implements OnInit {

  constructor(private db:DBService) { }

  ngOnInit() {
  }

  public SaveData(data:Employee)
  {
    this.db.saveEmployee(data).subscribe(p=>{
    alert('done!');
    });
  }
}

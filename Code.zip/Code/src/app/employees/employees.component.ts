import { Component, OnInit } from '@angular/core';
import { DBService } from '../db.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent {

  public Employees;
  constructor(private db:DBService){
    //this.Employees=[{"Id":101,"Name":"Nitin pandit","Salary":123456},{"Id":102,"Name":"Sonu pandit","Salary":23244},{"Id":103,"Name":"Poorva","Salary":12345},{"Id":104,"Name":"Kunal","Salary":87654},{"Id":105,"Name":"Punit","Salary":87654},{"Id":106,"Name":"Rohit","Salary":234599},{"Id":107,"Name":"Manish","Salary":34562}];

    this.db.getRecords().subscribe((res)=>{
      this.Employees=res;
    });
  }
}
